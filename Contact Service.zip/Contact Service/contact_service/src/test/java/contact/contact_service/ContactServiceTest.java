package contact.contact_service;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

// public class ContactServiceTest  with test methods for adding, deleting, and updating contacts
public class ContactServiceTest {
     
    @Test
    public void testAddContact() { // Test adding a contact
        ContactService service = new ContactService();
        Contact contact = new Contact("001", "John", "Doe", "1234567890", "123 Main St");
        service.addContact(contact);
        
        assertNotNull(service.getContact("001"));
        assertEquals("John", service.getContact("001").getFirst_Name());
    }

    @Test
    public void testAddDuplicateContactThrowsException() { // Test adding a duplicate contact
        ContactService service = new ContactService();
        Contact contact1 = new Contact("001", "John", "Doe", "1234567890", "123 Main St");
        Contact contact2 = new Contact("001", "Jane", "Smith", "0987654321", "456 Oak Ave");
        service.addContact(contact1);
        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(contact2);
        });
    }

    @Test
    public void testDeleteContact() { // Test deleting a contact
        ContactService service = new ContactService();
        Contact contact = new Contact("002", "Alice", "Brown", "1112223333", "789 Pine Rd");
        service.addContact(contact);
        service.deleteContact("002");
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteContact("002");
        });
    }

    @Test
    public void testUpdateFirstName() { // Test updating first name
        ContactService service = new ContactService();
        Contact contact = new Contact("003", "Mike", "Wazowski", "2223334444", "Monstropolis");
        service.addContact(contact);
        service.updateFirstName("003", "James");
        assertEquals("James", contact.getFirst_Name());
    }

    @Test
    public void testUpdateLastName() { // Test updating last name
        ContactService service = new ContactService();
        Contact contact = new Contact("004", "Sally", "Ride", "3334445555", "NASA Blvd");
        service.addContact(contact);
        service.updateLastName("004", "Fields");
        assertEquals("Fields", contact.getLast_Name());
    }

    @Test
    public void testUpdatePhone() { // Test updating phone number
        ContactService service = new ContactService();
        Contact contact = new Contact("005", "Buzz", "Lightyear", "4445556666", "Infinity St");
        service.addContact(contact);
        service.updatePhone("005", "9998887777");
        assertEquals("9998887777", contact.getPhone_Num());
    }

    @Test
    public void testUpdateAddress() { // Test updating address
        ContactService service = new ContactService();
        Contact contact = new Contact("006", "Woody", "Pride", "5556667777", "Andy's Room");
        service.addContact(contact);
        service.updateAddress("006", "Western Town");
        assertEquals("Western Town", contact.getAddressLine());
    }

    @Test
    public void testUpdateNonexistentContactThrowsException() { // Test updating a nonexistent contact
        ContactService service = new ContactService();
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateFirstName("999", "NewName");
        });
    }
}
