package contact.contact_service;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactTest {

	// Test cases for the Contact class
    @Test
    public void testValidContactCreation() {
        Contact contact = new Contact("001", "John", "Doe", "1234567890", "123 Main St");
        assertEquals("001", contact.getContactID());
        assertEquals("John", contact.getFirst_Name());
        assertEquals("Doe", contact.getLast_Name());
        assertEquals("1234567890", contact.getPhone_Num());
        assertEquals("123 Main St", contact.getAddressLine());
    }

    // public test methods for invalid contact creation
    @Test
    public void testInvalidContactIdTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345678901", "John", "Doe", "1234567890", "123 Main St");
        });
    }
    
    // Test methods for invalid contact creation with null or invalid parameters

    @Test
    public void testNullContactId() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, "John", "Doe", "1234567890", "123 Main St");
        });
    }

    // Test methods for invalid first name, last name, phone number, and address
    @Test
    public void testNullFirstName() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("002", null, "Doe", "1234567890", "123 Main St");
        });
    }

    // Test methods for first name too long
    @Test
    public void testFirstNameTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("005", "FirstnameTooLong", "Doe", "1234567890", "123 Main St");
        });
    }
    
    // Test methods for last name, phone number, and address validation

    @Test
    public void testNullLastName() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("006", "John", null, "1234567890", "123 Main St");
        });
    }

    // Test methods for last name too long
    @Test
    public void testLastNameTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("007", "John", "LastnameTooLong", "1234567890", "123 Main St");
        });
    }

    // Test methods for phone number validation
    @Test
    public void testPhoneNotTenDigits() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("003", "John", "Doe", "12345", "123 Main St");
        });
    }

    // Test methods for phone number null validation
    @Test
    public void testNullPhoneNumber() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("008", "John", "Doe", null, "123 Main St");
        });
    }
    
    // Test methods for address validation

    @Test
    public void testAddressTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("004", "John", "Doe", "1234567890", "1234567890123456789012345678901");
        });
    }

    //
    @Test
    public void testNullAddress() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("009", "John", "Doe", "1234567890", null);
        });
    }
}
