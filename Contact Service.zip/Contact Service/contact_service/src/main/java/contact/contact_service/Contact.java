package contact.contact_service;

// class Contact with private fields and public methods such as string getContactID(), string getFirst_Name(), string getLast_Name(), string getPhone_Num(), string getAddressLine(), and setters for first name, last name, phone number, and address

public class Contact {
    private final String contactID;     
    private String first_Name;         
    private String last_Name;          
    private String phone_Num;          
    private String addressLine;       
    
    // public contact constructor with parameters for contact ID, first name, last name, phone number, and address

    public Contact(String contactID, String first_Name, String last_Name, String phone_Num, String addressLine) {
        //if statements to validate the parameters
    	if (contactID == null || contactID.length() > 10)
            throw new IllegalArgumentException("Invalid contact ID");

        if (first_Name == null || first_Name.length() > 10)
            throw new IllegalArgumentException("Invalid first name");

        if (last_Name == null || last_Name.length() > 10)
            throw new IllegalArgumentException("Invalid last name");

        if (phone_Num == null || phone_Num.length() != 10)
            throw new IllegalArgumentException("Invalid phone number");

        if (addressLine == null || addressLine.length() > 30)
            throw new IllegalArgumentException("Invalid address");
      // this constructor assigns the parameters to the private fields
        this.contactID = contactID;
        this.first_Name = first_Name;
        this.last_Name = last_Name;
        this.phone_Num = phone_Num;
        this.addressLine = addressLine;
    }
    
    // public getter and setter methods for each private field

    public String getContactID() {
        return contactID;
    }

    public String getFirst_Name() {
        return first_Name;
    }
    // public setter method for first name with validation
    public void setFirst_Name(String first_Name) {
        if (first_Name == null || first_Name.length() > 10)
            throw new IllegalArgumentException("Invalid first name");
        this.first_Name = first_Name;
    }

    //public getter method for last name
    public String getLast_Name() {
        return last_Name;
    }
    // public setter method for last name with validation
    public void setLast_Name(String last_Name) {
        if (last_Name == null || last_Name.length() > 10)
            throw new IllegalArgumentException("Invalid last name");
        this.last_Name = last_Name;
    }
     // public getter method for phone number
    public String getPhone_Num() {
        return phone_Num;
    }
    // public setter method for phone number with validation
    public void setPhone_Num(String phone_Num) {
        if (phone_Num == null || phone_Num.length() != 10)
            throw new IllegalArgumentException("Invalid phone number");
        this.phone_Num = phone_Num;
    }
    // public getter method for address

    public String getAddressLine() {
        return addressLine;
    }
    // public setter method for address with validation
    public void setAddressLine(String addressLine) {
        if (addressLine == null || addressLine.length() > 30)
            throw new IllegalArgumentException("Invalid address");
        this.addressLine = addressLine;
    }
}
