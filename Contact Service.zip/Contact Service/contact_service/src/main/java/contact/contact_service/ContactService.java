package contact.contact_service;

import java.util.HashMap;
import java.util.Map;

// ContactService class with methods to add, delete, and update contacts
public class ContactService {
    private final Map<String, Contact> contacts = new HashMap<>(); // Map to store contacts with contact ID as the key
     // Method to add a contact
    public void addContact(Contact contact) {
        if (contacts.containsKey(contact.getContactID())){
            throw new IllegalArgumentException("Contact ID already exists.");
        }
        contacts.put(contact.getContactID(), contact);
    }
    
    // Method to delete a contact

    public void deleteContact(String contactId) {
        if (!contacts.containsKey(contactId)) {
            throw new IllegalArgumentException("Contact ID not found.");
        }
        contacts.remove(contactId);
    }

    // Method to update first name
    public void updateFirstName(String contactId, String firstName) {
        Contact contact = getContactById(contactId);
        contact.setFirst_Name(firstName);
    }
    
    // Method to update last name

    public void updateLastName(String contactId, String lastName) {
        Contact contact = getContactById(contactId);
        contact.setLast_Name(lastName);
    }
    
    // Method to update phone number

    public void updatePhone(String contactId, String phone) {
        Contact contact = getContactById(contactId);
        contact.setPhone_Num(phone);
    }
    
    // Method to update address

    public void updateAddress(String contactId, String address) {
        Contact contact = getContactById(contactId);
        contact.setAddressLine(address);
    }
    
    // Method to get a contact by ID

    private Contact getContactById(String contactId) {
        Contact contact = contacts.get(contactId);
        if (contact == null) {
            throw new IllegalArgumentException("Contact ID not found.");
        }
        return contact;
    }
    
    public Contact getContact(String contactId) {
        return contacts.get(contactId);
    }

}

